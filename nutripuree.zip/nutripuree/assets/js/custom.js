// our project section start here garden

// slider area
var swiper = new Swiper(".testmonial__wrapper", {
	spaceBetween: 24,
	loop: true,
	watchSlidesProgress: true,
	breakpoints: {
		576: {
			slidesPerView: 1,
		},
	},
	autoplay: {
		delay: 500000,
	},
});
var swiper = new Swiper(".case__wrapper", {
    spaceBetween: 24,
    direction: 'horizontal',
    loop: true,
    freeMode: true,
    watchSlidesProgress: true,
    centeredSlides: true,
    breakpoints: {
      1200: {
        slidesPerView: 3,
      },
      992: {
        slidesPerView: 2,
      }
    },
    navigation: {
      nextEl: '.case__next2',
      prevEl: '.case__prev2',
    },
    autoplay: {
      delay: 5000,
      disableOnInteraction: false,
      disableOnInteraction: false,
      reverseDirection: true,
    }
});
var swiper = new Swiper(".news__wrapper", {
    spaceBetween: 24,
    loop: true,
    watchSlidesProgress: true,
    breakpoints: {		
        1400: {
            slidesPerView: 3,
        },
        768: {
            slidesPerView: 2,
        },
    },
    autoplay: {
        delay: 3000,
    },
});

$("a,.sub-menu,button").on("mouseenter", function () {
    $(".mouseCursor").addClass("opacity-0");
});
$("a,.sub-menu,button").on("mouseleave", function () {
    $(".mouseCursor").removeClass("opacity-0");
});



(function ($) {
    "use strict";

    $(document).ready(function () {
        /*==== header Section Start here =====*/
        document.querySelector(".bar i").addEventListener("click", function () {
            let bar = document.querySelector(".bar i");
            bar.classList.toggle("fa-times");
            let target = document.querySelector(".target");
            target.classList.toggle("open");
        });

        /*==== header Section Start here =====*/
        $("ul>li>ul").parent("li").addClass("menu-item-has-children");
        // drop down menu width overflow problem fix
        $('ul').parent('li').on('hover', function () {
            var menu = $(this).find("ul");
            var menupos = $(menu).offset();
            if (menupos.right + menu.width() > $(window).width()) {
                var newpos = -$(menu).width();
                menu.css({
                    left: newpos
                });
            }
        });
        $('.header__nav li a').on('click', function (e) {
            var element = $(this).parent('li');
            if (screen.width < 1200) {
                if (element.hasClass('open')) {
                    element.removeClass('open');
                    element.find('li').removeClass('open');
                    element.find('ul').slideUp(300, "swing");
                } else {
                    element.addClass('open');
                    element.children('ul').slideDown(300, "swing");
                    element.siblings('li').children('ul').slideUp(300, "swing");
                    element.siblings('li').removeClass('open');
                    element.siblings('li').find('li').removeClass('open');
                    element.siblings('li').find('ul').slideUp(300, "swing");
                }
            }
        })

        //Header    
        var fixed_top = $(".header__bottom");
        $(window).on('scroll', function () {
            if ($(this).scrollTop() > 100) {
                fixed_top.addClass("header-fixed animated fadeInDown");
            } 
            else {
                fixed_top.removeClass("header-fixed animated fadeInDown");
            }
        });

        //Header ellipsis   
        var fixed_top = $(".header__bottom");
        $(window).on('scroll', function () {
            if ($(this).scrollTop() > 100) {
                fixed_top.addClass("ellepsis animated fadeInDown");
            } else {
                fixed_top.removeClass("ellepsis animated fadeInDown");
            }


        });
        
        // wow animation
        new WOW().init();

    });

	

}(jQuery));


// Preloader Js
$(window).on('load', function () {
    $('.overlayer').fadeOut(1000);
});

// partner host
var partner = new Swiper(".sponsor__slider", {
    loop: true,
    spaceBetween: 15,
    autoplay: {
        delay: 2000,
        disableOnInteraction: false,
        reverseDirection: true,
    },
    breakpoints: {
        0: {
            slidesPerView: 2,
        },
        768: {
            slidesPerView: 3,
        },
        992: {
            slidesPerView: 4,
        },
        1200: {
            slidesPerView: 5,
        },
    },
});


const pathName = window.location.pathname;
const pageName = pathName.split("/").pop();

if(pageName === "index.html"){
    document.querySelector(".home").classList.add("active");
}
if(pageName === "price.html"){
    document.querySelector(".pricepage").classList.add("active");
}
if(pageName === "about.html"){
    document.querySelector(".about").classList.add("active");
}
if(pageName === "services.html"){
    document.querySelector(".services").classList.add("active");
}
if(pageName === "news.html"){
    document.querySelector(".news").classList.add("active");
}
if(pageName === "news-single.html"){
    document.querySelector(".news-single").classList.add("active");
}
if(pageName === "404.html"){
    document.querySelector(".error").classList.add("active");
}
if(pageName === "contact.html"){
    document.querySelector(".contact").classList.add("active");
}